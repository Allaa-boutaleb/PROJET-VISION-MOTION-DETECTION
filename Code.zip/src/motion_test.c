/* --------------------- */
/* --- motion_test.c --- */
/* --------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <math.h>

#include "motion.h"

// ====================================
int test_motion(int argc, char* argv[])
// ====================================
{
    puts("=== test_motion ===");
    motion_detection_morpho();
    
  return 0;
}
